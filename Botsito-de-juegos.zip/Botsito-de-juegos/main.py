import os
from telegram import Update
from telegram.ext import Application, CommandHandler, ContextTypes
import requests
from bs4 import BeautifulSoup
import logging
import asyncio

# Configuración de logging
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# Variables globales
last_games = []

# Obtener configuración de Secrets
TOKEN = os.environ['TELEGRAM_TOKEN']
CHAT_ID = os.environ.get('CHAT_ID', '')
XBOX_NOW_URL = 'https://www.xbox-now.com/es/game-comparison'

async def get_chat_id(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Comando para obtener el chat ID"""
    chat_id = update.effective_chat.id
    await update.message.reply_text(f'💡 Tu Chat ID es: {chat_id}')

def scrape_xbox_now():
    """Obtiene los juegos de Xbox-Now"""
    global last_games
    try:
        headers = {'User-Agent': 'Mozilla/5.0'}
        response = requests.get(XBOX_NOW_URL, headers=headers)
        soup = BeautifulSoup(response.text, 'html.parser')
        current_games = []

        # Ajusta este selector según la estructura actual de la página
        game_elements = soup.select('.game-title') or soup.find_all('h3')

        for element in game_elements:
            game_name = element.text.strip()
            if game_name:
                current_games.append(game_name)

        if not last_games:
            last_games = current_games
            return None

        new_games = [game for game in current_games if game not in last_games]

        if new_games:
            last_games = current_games
            return new_games

        return None

    except Exception as e:
        logger.error(f"Error en scraping: {e}")
        return None

async def check_for_updates(context: ContextTypes.DEFAULT_TYPE):
    """Verifica actualizaciones y envía notificaciones"""
    new_games = scrape_xbox_now()
    if new_games and CHAT_ID:
        message = "🎮 Nuevos juegos en Xbox-Now!\n\n" + "\n".join(f"• {game}" for game in new_games)
        await context.bot.send_message(chat_id=CHAT_ID, text=message)

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Maneja el comando /start"""
    await update.message.reply_text('Bot de Xbox-Now iniciado. Usa /id para ver tu Chat ID')

async def manual_scan(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Comando para escanear manualmente"""
    await update.message.reply_text("🔍 Escaneando Xbox-Now...")
    new_games = scrape_xbox_now()
    if new_games:
        message = "🎮 Nuevos juegos:\n\n" + "\n".join(f"• {game}" for game in new_games)
    else:
        message = "ℹ️ No hay nuevos juegos"
    await update.message.reply_text(message)

async def post_init(application: Application):
    """Configura las tareas programadas después de la inicialización"""
    job_queue = application.job_queue
    if job_queue:
        job_queue.run_repeating(check_for_updates, interval=3600, first=10)
    else:
        logger.warning("JobQueue no está disponible. Las actualizaciones automáticas no funcionarán.")

def main():
    """Función principal"""
    # Configurar el Application con el JobQueue
    application = Application.builder().token(TOKEN).post_init(post_init).build()

    # Comandos
    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("id", get_chat_id))
    application.add_handler(CommandHandler("scan", manual_scan))

    # Iniciar bot
    logger.info("Bot iniciado...")
    application.run_polling()

if __name__ == '__main__':
    if 'TELEGRAM_TOKEN' not in os.environ:
        logger.error("❌ ERROR: Falta TELEGRAM_TOKEN en Secrets")
    else:
        scrape_xbox_now()  # Scraping inicial
        main()
        from flask import Flask
        app = Flask(__name__)

        @app.route('/')
        def home():
            return "Bot activo"

        if __name__ == '__main__':
            app.run(host='0.0.0.0', port=8080)